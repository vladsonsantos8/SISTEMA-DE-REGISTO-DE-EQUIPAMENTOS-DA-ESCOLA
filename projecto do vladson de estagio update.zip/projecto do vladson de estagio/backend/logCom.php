<?php
include 'db_conect.php';
session_start();
if(isset($_POST['btn'])){
    echo"clicou";
};
$servname="localhost";
$username="root";
$password="";
$db_name="adms";

$conection=mysqli_connect($servname,$username,$password,$db_name);
if(mysqli_connect_error()){
    echo"lha na coneção".mysqli_connect_error();
}

?>
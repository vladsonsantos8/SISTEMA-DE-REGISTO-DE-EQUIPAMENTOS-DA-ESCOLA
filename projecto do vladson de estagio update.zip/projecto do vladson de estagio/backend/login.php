
<?php
include 'db_conect.php';
session_start();

if(isset($_POST['btn'])){
  
    $erros = array();
    $email = mysqli_real_escape_string($conn,($_POST['email']));
    $senha = mysqli_real_escape_string($conn,($_POST['pass']));

    if(empty($senha) or empty($email)){
        $erros[] = "<li>O campo email/senha precisa ser preenchido</li>";
    } else {
        $sql = "SELECT * FROM users WHERE email='$email'";
        $result = mysqli_query($conn,$sql);

  
        if(mysqli_num_rows($result) > 0){
       
            $sql = "SELECT * FROM users WHERE senha='$senha' AND email='$email'";
            $result = mysqli_query($conn, $sql);

            if(mysqli_num_rows($result) == 1){
  
                $dados = mysqli_fetch_array($result);
                $_SESSION['logado'] = true;
                $_SESSION['id_usuario'] = $dados['id'];
                $_SESSION['nome_do_user']=$dados['nome'];
                header('location:equipamentos.php');
                exit();
            } else {
                $erros[] = "<li>Usuário e senha não coincidem</li>";
            }
        } else {
            $erros[] = "<li>Usuário inexistente</li>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body{
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100vh;
    flex-direction: column;
    font-family: Arial,sans-serif;
    font-weight:1px;
    background-color:rgb(255, 255, 255);
}
@keyframes subir {
  0%{
opacity: 0%;
    transform: translateY(50%);
  }  
  100%{
    opacity: 100%;
    transform: translateY(-5%);
  }
}
form{
    background-color:rgb(255, 255, 255);
   border-radius: 100px;
    width: 400px;
  box-shadow:0px 25px 50px -12px #6e749b40;
    height: 520px;
    margin: 7px;
    padding:20px 20px 20px 20px;
    border-radius: 1px;
    display: flex;
    flex-direction: column;
    gap: 10px;
    justify-content: center;
    animation:subir 3s ;
}
h1{
    align-self: center;
    font-weight: bolder;
    font-size: 40px;
}
span{
    color: rgb(30, 65, 173);
}
input{
    border: 2px solid;
    border-radius: 1px;
    padding: 20px;
}
input:hover{
    border: solid 2px rgb(30, 65, 173);
}
button{
   width: 402px;
   border-radius: 1px; 
   outline: none;
   padding: 20px;
   font-weight: bolder;
   color: white;
   background-color: rgb(30, 65, 173);
}
button:active{
    background-color: white;
    color: rgb(30, 65, 173);
}
#div1{
    display:flex;
    align-self:center;

width:300px;
}
#div2{
    display:flex;
    align-self:center; 

width:50%;
}

    </style>
</head>
<html>
<body>
 <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
       <h1>ADM</h1>
      </div>  
    <?php
    if(!empty($erros)){
        foreach($erros as $erro){
            echo $erro;
        };
    };
    ?>
    <label for="">user</label>
    <input type="text" name="nome"  placeholder="name">
    <label for="">password</label>
    <input type="password" name="pass" placeholder="password" autocomplemente="curret-password" >
    <label for="">Email</label>
    <input type="email" name="email" placeholder="email" autocomplemente="email" >
    <button type="submit" name="btn">Enter</button>
   </form>
</body>
</html>
  
<?php 

session_start();
if(!isset($_SESSION["logado"]) || $_SESSION["logado"]==false){
    header("location:login.php");
exit();
}
?>
<?php
if(isset($_POST['btn'])){
$tipo = mysqli_real_escape_string($conn,($_POST['tipo']));
$estado = mysqli_real_escape_string($conn,($_POST['estado']));
$local = mysqli_real_escape_string($conn,($_POST['local']));
$nome = mysqli_real_escape_string($conn,($_POST['nome']));
$descrição = mysqli_real_escape_string($conn,($_POST['descrição']));
$dataRegistro = mysqli_real_escape_string($conn,($_POST['DataRegistro']));

$sql = "INSERT INTO equipamentos VALUES(DEFAULT,'$nome','$decrição','$tipo','$dataRegistro','$estado','$local')";
        if(mysqli_query($conn,$sql)){

            $_SESSION['adm'] = true;
            $_SESSION['id_usuario'] = $dados['id'];
            $_SESSION['nome_do_user']=$dados['nome'];
            
        }else{
            header("location:registro.php");
            echo"<li>ERRO</li>";
        };
};
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro Adim</title>
    <style>
        *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: "Segoe UI", Arial, sans-serif;
    }
        body{
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100vh;
    overflow:hidden;
    flex-direction: row;
    font-family: sans-serif;
    background-color:rgb(255, 255, 255);
}

    .barra-lateral{
        width: 260px;
        height: 100%;
        background: #2d558a;
        color: white;
        padding: 25px 20px;
        display: flex;
        flex-direction: column;
    }

    .barra-lateral-titulo{
        font-size: 22px;
        font-weight: bold;
        margin-bottom: 40px;
        text-align: center;
    }

    .menu-lateral a{
        text-decoration: none;
        color: white;
        padding: 14px 15px;
        display: block;
        margin-bottom: 12px;
        background: rgba(255,255,255,0.15);
        border-radius: 6px;
        transition: 0.25s;
        font-size: 15px;
    }

    .menu-lateral a:hover{
        background: #2d558a;
    }

    .area-principal{
        flex: 1;
        display: flex;
        flex-direction: column;
        height: 100%;
        overflow: hidden;
    }

    .cabecalho{
        background: white;
        height: 60px;
        display: flex;
        align-items: center;
        padding: 0 25px;
        border-bottom: 1px solid #D0D4D8;
        justify-content: space-between;
    }

    .cabecalho-titulo{
        font-size: 20px;
        font-weight: bold;
        color: #333333;
    }

    .caixa-usuario{
        background: #2d558a;
        padding: 8px 14px;
        border-radius: 50px;
        color: white;
        font-size: 14px;
        cursor: pointer;
    }

  
    .conteudo{
        padding: 25px;
        height: calc(100vh - 60px);
        overflow-y: auto;
    }


form{
    background-color:rgb(255, 255, 255);
   border-radius: 100px;
    width: 100%;
   box-shadow:0px 25px 50px -12px #6e749b40;
    height: 500px;
    margin: 7px;
    padding:20px 20px 20px 20px;
    border-radius: 1px;
    display: flex;
    flex-direction: column;
    gap: 10px;
    justify-content: center;
    animation:subir 3s ;
    
}
h1{
    align-self: center;
    font-weight: bolder;
    font-size: 40px;
}
span{
    color: rgb(30, 65, 173);
}
input{
    border: 2px solid;
    border-radius: 1px;
    padding: 20px;
}
input:hover{
    border: solid 2px rgb(30, 65, 173);
}
button{
   
   border-radius: 1px; 
   outline: none;
   padding: 20px;
   font-weight: bolder;
   color: white;
   background-color: rgb(30, 65, 173);
}
button:active{
    background-color: white;
    color: rgb(30, 65, 173);
}
#div1{
    display:flex;
    align-self:center;
width:300px;
}
#div2{
    display:flex;
    align-self:center; 
width:50%;
}

    </style>
</head>
<html>
<body>
<div class="barra-lateral">
    <h2 class="barra-lateral-titulo">Inventário Escolar</h2>

    <div class="menu-lateral">
        <a href="painel.php"> Painel Inicial</a>
        <a href="registroDeEquipamento.php"> Registar Equipamento</a>
         <a href="equipamentos.php"> Lista de Equipamentos</a>
        <a href="#"> Definições</a>
        <a href="logout.php"> Terminar Sessão</a>
        <a href="registro.php">Registrar Administrador</a>
    </div>
</div>

<div class="area-principal">

    
    <div class="cabecalho">
        <div class="cabecalho-titulo">Sistema de Registo de Equipamentos</div>
        <div class="caixa-usuario"><?php echo $_SESSION['nome_do_user'] ?></div>
    </div>

    <div class="conteudo">
 <form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">

    <label for="">nome do Equipamento</label>
    <input type="text" name="nome" placeholder="nome" required>

    <label for="">Tipo de equipamento</label>
    <input type="text" name="tipo"  placeholder="tipo" required>

    <label for="">Estado</label>
    <input type="text" name="estado" placeholder="Funcional/Avariado" required>

     <label for="">Local</label>
    <input type="text" name="local" placeholder="localizaçaõ" required>
    
    <input type="date" hidden name="DataRegistro" placeholder="Data de Registro">

    <button type="submit" name="btn">ADD</button>
   </form>
    </div>
</body>
</html>
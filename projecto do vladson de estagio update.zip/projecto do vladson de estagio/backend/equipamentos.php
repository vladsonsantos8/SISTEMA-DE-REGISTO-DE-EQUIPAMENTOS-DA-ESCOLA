
<?php
include 'db_conect.php';
session_start();
if(!isset($_SESSION["logado"]) || $_SESSION["logado"]==false){
    header("location:login.php");
exit();
};


if(isset($_SESSION["logado"])){
    $sql="SELECT nome,tipo,data_registro,estado,localização FROM Equipamentos ORDER BY id DESC";
    $result=mysqli_query($conn,$sql);
}
function contarEquipamentos($conn){
    $sql="SELECT COUNT(nome) AS total_equipamentos from equipamentos";
    $result=mysqli_query($conn,$sql);
    return $result;
}


function contarAvariados($conn){
    $sql="SELECT COUNT(*) AS total_avariados from equipamentos where estado='avariado'";
    $result=mysqli_query($conn,$sql);
    return $result;
}
function contarFuncionais($conn){
    $sql="SELECT COUNT(*) AS total_funcionais from equipamentos where estado='Funcional'";
    $result=mysqli_query($conn,$sql);
    return $result;
}
$resultado=contarEquipamentos($conn);
$resultado2=contarAvariados($conn);
$resultado3=contarFuncionais($conn);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
     <style>
        *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: "Segoe UI", Arial, sans-serif;
    }
    body{
        background: #F4F6F8;
        display: flex;
        height: 100vh;
        overflow: hidden;
    }

   
    .barra-lateral{
        width: 260px;
        background: #2d558a;
        color: white;
        padding: 25px 20px;
        display: flex;
        flex-direction: column;
    }

    .barra-lateral-titulo{
        font-size: 22px;
        font-weight: bold;
        margin-bottom: 40px;
        text-align: center;
    }

    .menu-lateral a{
        text-decoration: none;
        color: white;
        padding: 14px 15px;
        display: block;
        margin-bottom: 12px;
        background: rgba(255,255,255,0.15);
        border-radius: 6px;
        transition: 0.25s;
        font-size: 15px;
    }

    .menu-lateral a:hover{
        background: #2d558a;
    }

    .area-principal{
        flex: 1;
        display: flex;
        flex-direction: column;
        height: 100%;
        overflow: hidden;
    }

    .cabecalho{
        background: white;
        height: 60px;
        display: flex;
        align-items: center;
        padding: 0 25px;
        border-bottom: 1px solid #D0D4D8;
        justify-content: space-between;
    }

    .cabecalho-titulo{
        font-size: 20px;
        font-weight: bold;
        color: #333333;
    }

    .caixa-usuario{
        background: #2d558a;
        padding: 8px 14px;
        border-radius: 50px;
        color: white;
        font-size: 14px;
        cursor: pointer;
    }

  
    .conteudo{
        padding: 25px;
        height: calc(100vh - 60px);
        overflow-y: auto;
    }

  
    .caixas-info{
        display: flex;
        gap: 20px;
        margin-bottom: 25px;
    }

    .caixa-info{
        flex: 1;
        background: white;
        border: 1px solid #D0D4D8;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.08);
    }

    .caixa-info h3{
        font-size: 16px;
        color: #333333;
        margin-bottom: 8px;
    }

    .caixa-info span{
        font-size: 26px;
        font-weight: bold;
    }

    table{
        width: 100%;
        border-collapse: collapse;
        background: white;
        border-radius: 6px;
        overflow: hidden;
        box-shadow: 0 1px 3px rgba(0,0,0,0.12);
    }

    th{
    background: #2d558a;
        color: white;
        padding: 11px;
        text-align: left;
        font-size: 15px;
    }

    td{
        padding: 12px;
        font-size: 14px;
        color: #333333;
        border-bottom: 1px solid #D0D4D8;
    }

    tr:hover{
        background: #F0F7FF;
    }

    .estado-funcional{
        color: #34A853;
        font-weight: bold;
    }

    .estado-avariado{
        color: #EA4335;
        font-weight: bold;
    }

     </style>
</head>
<body>
 
<div class="barra-lateral">
    <h2 class="barra-lateral-titulo">Inventário Escolar</h2>

    <div class="menu-lateral">
        <a href="painel.php"> Painel Inicial</a>
        <a href="registroDeEquipamento.php"> Registar Equipamento</a>
        <a href="equipamentos.php"> Lista de Equipamentos</a>
        <a href="#"> Definições</a>
        <a href="logout.php"> Terminar Sessão</a>
        <a href="registro.php">Registrar Administrador</a>
    </div>
</div>

<div class="area-principal">


    <div class="cabecalho">
        <div class="cabecalho-titulo">Lista de Equipamentos</div>
        <div class="caixa-usuario"><?php echo $_SESSION['nome_do_user'] ?></div>
    </div>

    <div class="conteudo">

        <table>
            <tr>
                <th>nome<th>
                <th>tipo</th>
                <th>estado</th>
                <th>local</th>
            </tr>

            <tr> 
           <?php if(mysqli_num_rows($result)>0){ ?>
           <?php while($date=mysqli_fetch_assoc($result)){ ?> 

                <td><?php echo $date["nome"];?></td>
                <td><?php echo $date["tipo"];?></td>
                <td class="estado-funcional"><?php echo $date["estado"]; ?></td>
                <td><?php echo $date["localização"]; ?></td>
                <td><?php echo $date["data_registro"]; ?></td>
            </tr>
<?php }; ?>
<?php }; ?>
        </table>

    </div>
</div>
</body>
</html>